import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import '../models/user.dart';
import '../data/book.dart'; // Your mock or real book data
import '../models/section.dart';

class HomeScreen extends StatefulWidget {
  final User user;

  const HomeScreen({super.key, required this.user});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Section? currentSection;
  Map<String, bool> completedSections = {};

  @override
  void initState() {
    super.initState();
    _loadTodaySection();
    _loadUserProgress();
  }

  void _loadTodaySection() {
    final today = DateTime.now();
    final daysSinceStart = today.difference(widget.user.startDate).inDays;

    if (daysSinceStart >= 0 && daysSinceStart < book.sections.length) {
      currentSection = book.sections[daysSinceStart];
    } else {
      currentSection = null; // Either not started yet or finished
    }
  }

  void _loadUserProgress() {
    final box = Hive.box('readingBox');
    final key = 'progress_${widget.user.id}';
    final savedProgress = Map<String, bool>.from(box.get(key) ?? {});
    setState(() {
      completedSections = savedProgress;
    });
  }

  void _markAsCompleted(Section section) {
    final box = Hive.box('readingBox');
    final key = 'progress_${widget.user.id}';

    setState(() {
      completedSections[section.id] = true;
      box.put(key, completedSections);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (currentSection == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Daily Reading')),
        body: const Center(
          child: Text(
            'No section available today.',
            style: TextStyle(fontSize: 18),
          ),
        ),
      );
    }

    final isCompleted = completedSections[currentSection!.id] ?? false;

    return Scaffold(
      appBar: AppBar(
        title: Text('Welcome, ${widget.user.name}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              // Reset user (optional feature)
              final box = Hive.box('readingBox');
              box.delete('selectedUserId');
              Navigator.pushReplacementNamed(context, '/select-user');
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Today\'s Section',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            Text(
              currentSection!.title!,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: SingleChildScrollView(
                child: Text(
                  currentSection!.content,
                  style: const TextStyle(fontSize: 16),
                ),
              ),
            ),
            const SizedBox(height: 24),
            if (!isCompleted)
              ElevatedButton.icon(
                onPressed: () => _markAsCompleted(currentSection!),
                icon: const Icon(Icons.check),
                label: const Text('Mark as Read'),
              )
            else
              const Text(
                '✅ Completed',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.green,
                  fontWeight: FontWeight.bold,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
