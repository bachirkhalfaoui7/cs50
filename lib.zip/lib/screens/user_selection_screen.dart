import 'package:flutter/material.dart';
import '../data/users.dart';
import 'home_screen.dart';

class UserSelectionScreen extends StatelessWidget {
  const UserSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Select Your Name')),
      body: ListView.builder(
        itemCount: predefinedUsers.length,
        itemBuilder: (context, index) {
          final user = predefinedUsers[index];
          return ListTile(
            title: Text(user.name),
            onTap: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (_) => HomeScreen(user: user),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
