class Section {
  final String id;
  final int dayIndex;
  final String content;

  Section({
    required this.id,
    required this.dayIndex,
    required this.content, required String title,
  });

  String? get title => null;
}
