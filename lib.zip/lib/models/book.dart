import 'section.dart';

class Book {
  final String id;
  final String title;
  final List<Section> sections;

  Book({
    required this.id,
    required this.title,
    required this.sections,
  });
}
