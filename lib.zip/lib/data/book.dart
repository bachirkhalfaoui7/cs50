import '../models/book.dart';
import '../models/section.dart';

final book = Book(
  title: 'Sample Book',
  sections: List.generate(
    30,
    (index) => Section(
      id: 'day_${index + 1}',
      title: 'Day ${index + 1}',
      content: 'This is the reading content for day ${index + 1}.',
      dayIndex: index, // ✅ FIXED: use index instead of null
    ),
  ),
  id: '',
);
