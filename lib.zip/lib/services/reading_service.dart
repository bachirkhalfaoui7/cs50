import '../models/user.dart';
import '../models/book.dart';
import '../models/section.dart';

class ReadingService {
  static int calculateCurrentDayIndex(DateTime startDate) {
    final now = DateTime.now();
    final diff = now.difference(startDate).inDays;
    return diff >= 0 ? diff : -1;
  }

  static Section? getTodaySection(User user, Book book) {
    final index = calculateCurrentDayIndex(user.startDate);
    if (index < 0 || index >= book.sections.length) return null;
    return book.sections[index];
  }

  static bool isSectionCompleted(User user, Section section) {
    return user.completedSections[section.id] ?? false;
  }

  static void markSectionAsCompleted(User user, Section section) {
    user.completedSections[section.id] = true;
    // You’d persist this in real app
  }
}
